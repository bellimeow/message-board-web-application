var assert = require('assert');
var expect = require("chai").expect;
var request = require("superagent");
var express = require("../lab2/express.js");

describe("Starta upp server.", function() {
    it("Anropa startServer().", function() {
        express.startServer();
    });
});

describe("Det skall finnas möjlighet att via ett HTTP anrop till den utvecklade Express.js applikationen spara ett nytt meddelande i MongoDB.", function() {
    it("Gör GET request till localhost/save med superagent och ajax.", function(done) {
        request.get('http://localhost:3021/save').query({ message: 'Testing sucks!' }).then(function(res) {
            expect(res.status).to.equal(200);
            done();
        });
    });
});

describe("Det skall finnas möjlighet att via ett HTTP anrop till den utvecklade Express.js applikationen hämta alla meddelanden som har sparats i MongoDB (returneras som JSON).", function() {
    it("Gör GET request till localhost/getall.", function(done) {
        request.get("http://localhost:3021/getall").then(function(res) {
            expect(res.status).to.equal(200);
            expect(res.body).to.not.equal(null);
            done();
        });
    });
});

describe("Det skall finnas möjlighet att via ett HTTP anrop till den utvecklade Express.js applikationen markera ett meddelande som läst i MongoDB.", function() {
    it("Gör GET request till localhost/getall för att hämta meddelanden och därefter till localhost/flag för att markera det första meddelandet som läst..", function(done) {
        request.get("http://localhost:3021/getall").then(function(res) {
            expect(res.status).to.equal(200);
            expect(res.body).to.not.equal(null);
            var firstMessage = res.body[0];
            request.get("http://localhost:3021/flag").query({ ID: firstMessage._id }).then(function(res) {
                expect(res.status).to.equal(200);
                done();
            });
        });
    });
});

describe("Om anropet inte mappar mot en funktion skall HTTP 404 returneras.", function() {
    it("Gör GET request till localhost/nope.", function(done) {
        request.get("http://localhost:3021/nope").then().catch(function(err) {
            expect(err.status).to.equal(404);
            done();
        });
    });
});

describe("Om anropet använder fel metod skall HTTP 405 returneras.", function() {
    it("Gör POST request till localhost/save.", function(done) {
        request.post('http://localhost:3021/save').send("message=Testing definitely sucks!").then().catch(function(err) {
            expect(err.status).to.equal(405);
            done();
        });
    });
});

describe("Om anropet använder felaktiga eller saknar parameterar skall HTTP 400 returneras.", function() {
    it("Gör GET request till localhost/save utan parameterar.", function(done) {
        request.get('http://localhost:3021/save').then().catch(function(err) {
            expect(err.status).to.equal(400);
            done();
        });
    });request.get('http://localhost:3021/save').then().catch(function(err) {
            expect(err.status).to.equal(400);
            done();
        });
    it("Gör GET request till localhost/save utan 'message' parameter.", function(done) {
        request.get('http://localhost:3021/save').query({ notmessage: "I'm pretty sure testing sucks by now." }).then().catch(function(err) {
            expect(err.status).to.equal(400);
            done();
        });
    });
    it("Gör GET request till localhost/flag utan parameterar.", function(done) {
        request.get('http://localhost:3021/flag').then().catch(function(err) {
            expect(err.status).to.equal(400);
            done();
        });
    });
    it("Gör GET request till localhost/flag utan 'ID' parameter.", function(done) {
        request.get('http://localhost:3021/flag').query({ NotID: "You expected an ID, but I'm here to tell you that testing SUCKS!" }).then().catch(function(err) {
            expect(err.status).to.equal(400);
            done();
        });
    });
});

describe("Vid alla andra fel returneras HTTP 500.", function() {
    it("Gör GET request till localhost/flag med felaktigt ID.", function(done) {
        request.get('http://localhost:3021/flag').query({ ID: "You expected a valid ID, but this is not an accepted mongodb ID. Also testing SUCKS." }).then().catch(function(err) {
            expect(err.status).to.equal(500);
            done();
        });
    });
    it("Gör GET request till localhost/flag med ett korrekt ID som inte existerar.", function(done) {
        request.get('http://localhost:3021/flag').query({ ID: "aaaaaaaaaaaaaaaaaaaaaaaa" }).then().catch(function(err) {
            expect(err.status).to.equal(500);
            done();
        });
    });
});

describe("Alla funktioner skall testas med Mocha. Tänk på att använda istanbul så att ni får code-coverage rapporter.", function() {
    it("Skapa ny route /newroute, starta därefter om servern och prova den nya routen.", function(done) {
        express.route("get", "/newroute", function(req, res) {
            res.sendStatus(200);
        });
        express.stopServer();
        express.startServer();
        request.get('http://localhost:3021/newroute').then(function(res) {
            expect(res.status).to.equal(200);
            done();
        });
    });
    it("Anropa hjälpfunktion för databasen.", function(done) {
        express.accessCollection("messages", function(db, messages) {
            done();
        });
    });
});

describe("Stäng ner server.", function() {
    it("Anropa stopServer().", function() {
        express.stopServer();
    });
});

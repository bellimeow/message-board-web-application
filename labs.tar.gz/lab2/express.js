const ExpressApp = require("express")();
const ExpressPort = 3021;
const MongoClient = require('mongodb').MongoClient;
const MongoURL = "mongodb://localhost:27017/";
const ObjectID = require('mongodb').ObjectID;

/*******************************************************************************
        ROUTES
*******************************************************************************/

// curl -d "msg=hej" -X POST http://localhost/msg_new

// We created our own convenience function for setting up routes.
// See "function route" below.

/**
* This is the route used to add new messages to the message board. The messages
* are saved to a collection 'messages' in the Mongo database.
 **/
route("get", "/save", function(req, res) {
    var message = req.query.message;

    if (message && message.length > 0 && message.length <= 140) {
        accessCollection("messages", function(db, messages) {
            messages.insertOne({ "message": message, "flag": false, }, function(err) {
                if (err) throw err;

                // Send OK status!
                res.sendStatus(200);

                db.close();
            });
        });
    }
    else {
        // Send bad request.
        res.sendStatus(400);
    }
});

route("get", "/flag", function(req, res) {
    // Required parameters.
    var id = req.query.ID;

    if (id) {
        accessCollection("messages", function(db, messages) {
            // Convert id to proper object recognized by MongoDB.
            try {
                id = ObjectID(id);
                messages.findOne(id, function(err, findRes) {
                    if (err) throw err;

                    if (findRes) {
                        // Update attribute value of the entry.
                        findRes.flag = true;

                        // Update the database entry.
                        messages.update({ "_id": id }, findRes, {}, function(err, updateRes) {
                            if (err) throw err;

                            res.sendStatus(200);

                            db.close();
                        });
                    }
                    else {
                        res.sendStatus(500);
                    }
                });
            }
            catch(err) {
                res.sendStatus(500);
            }
        });
    }
    else {
        res.sendStatus(400);
    }
});

/**
* This is the route used to get all existing messages on the message board.
 **/
route("get", "/getall", function(req, res) {
    accessCollection("messages", function(db, messages) {
        messages.find().toArray(function(err, findRes) {
            res.send(findRes);

            db.close();
        });
    });

});

var server = null;
function startServer() {
    server = ExpressApp.listen(ExpressPort, function() {
        var host = server.address().address;
        var port = server.address().port;

        console.log('Example app listening at http://%s:%s', host, port);
    });
}
function stopServer() {
    if (server) {
        server.close();
        server = null;
    }
}

if (!module.parent) {
    startServer();
}

/*******************************************************************************
    DEFAULT ROUTE HANDLERS
*******************************************************************************/

// Function to set up a main method handler and use a default 405 handler for other methods.
function route(method, route, callback) {
    const allMethods = [
        "get",
        "post",
        "put",
        "head",
        "delete",
        "patch",
        "options",
    ];

    // Call the function by it's name.
    ExpressApp[method](route, callback);

    // Loop through other methods and assign default handler.
    var i;
    for (var i = 0; i < allMethods.length; ++i) {
        if (allMethods[i] != method) {
            ExpressApp[allMethods[i]](route, function (req, res) {
                res.sendStatus(405);
            });
        }
    }
}

function accessCollection(collectionName, callback) {
    MongoClient.connect(MongoURL, function(err, db) {
        if (err) throw err;

        var dbo = db.db("tdp013");
        var collection = dbo.collection(collectionName);

        callback(db, collection);
    });
}

var exports = module.exports = {};
exports.startServer = startServer;
exports.stopServer = stopServer;
exports.route = route;
exports.accessCollection = accessCollection;

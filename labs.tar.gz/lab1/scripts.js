

function validateInput() {
    /**/
    var message = document.getElementById("message").value;
    if (message.length > 140) {
        showPopup();
    } else if (message.length > 0) {
        hidePopup();
        postMessage(message);
    }
}

var hidePopupTimerId
function showPopup() {
    var popup = document.getElementById("mypopup");
    popup.classList.add("show");
    window.clearTimeout(hidePopupTimerId);
    hidePopupTimerId = window.setTimeout(hidePopup, 3000);
}
function hidePopup() {
    var popup = document.getElementById("mypopup");
    popup.classList.remove("show");
}

function markElementAsRead(element, flag) {
    if (flag) {
        element.classList.remove("alert-primary");
        element.classList.add("alert-light");
    }
    else {
        element.classList.remove("alert-light");
        element.classList.add("alert-primary");
    }
}

var postedMessages = new Array();

function postMessage(message) {
    postedMessages.unshift({ text: message, read: false, });
    if (postedMessages.length > 5) {
        postedMessages.pop();
    }

    var i;
    for (i = 0; i < postedMessages.length; i++) {
        var post = postedMessages[i];
        var postedMessageElement = document.getElementById("posted-message-" + i);

        postedMessageElement.classList.add("show");

        markElementAsRead(postedMessageElement, post.read);

        document.getElementById("posted-message-text-" + i).innerHTML = post.text;
    }
}

function markAsRead(id) {
    var element = document.getElementById("posted-message-" + id);
    markElementAsRead(element, true);

    postedMessages[id].read = true;
}

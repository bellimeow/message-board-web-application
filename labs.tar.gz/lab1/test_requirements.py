import unittest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

class UnitTest(unittest.TestCase):
    def setUp(self):

        self.driver = webdriver.Chrome(executable_path=r'/bin/chromedriver')

    def test_document(self):
        driver = self.driver
        driver.get("file:///home/isade842/Documents/TDP013/lab1/lab1.html")

        self.assertIn("Message board", driver.title)

    def test_max_characters(self):
        #TODO: En användare skall kunna skriva in ett meddelande i ett fält, meddelandet får max ha 140 tecken.

        driver = self.driver
        driver.get("file:///home/isade842/Documents/TDP013/lab1/lab1.html")

        user_message = driver.find_element_by_name("user_message")
        pop_up = driver.find_element_by_name("mypopup")

        user_message.send_keys("a"*140)
        user_message.send_keys(Keys.RETURN)
        assert (not pop_up.is_displayed()), "Max characters exceeded and popup should have been hidden"
        user_message.clear()

        user_message.send_keys("b"*141)
        user_message.send_keys(Keys.RETURN)
        time.sleep(1)
        assert (pop_up.is_displayed()), "Max characters exceeded but popup was not shown!"
        user_message.clear()

    def test_user_message_click(self):
        #TODO: En användare skall kunna, genom att klicka på en knapp, publicera sitt meddelande. Innan meddelandet publiceras skall det valideras med JavaScript. Om meddelandet är tomt eller mer än 140 tecken skall det inte publiceras och ett felmeddelande skall visas för användare (obs, använd inte "alert" för felmeddelande).

        driver = self.driver
        driver.get("file:///home/isade842/Documents/TDP013/lab1/lab1.html")

        post_button = driver.find_element_by_name("button")
        user_message = driver.find_element_by_name("user_message")
        posted_message_0 = driver.find_element_by_name("posted-message-0")

        post_button.click()
        assert (not posted_message_0.is_displayed()), "This empty user message has not been posted on button click"

        user_message.send_keys("Hej på dig!")
        post_button.click()
        assert (posted_message_0.is_displayed()), "This empty user message has not been posted on button click"
        user_message.clear()

    def test_chronologic_posted_messages(self):
        #TODO: Ett meddelande som är publicerat skall visas i kronologiskt fallande (senast först) ordning nedanför textfältet.

        driver = self.driver
        driver.get("file:///home/isade842/Documents/TDP013/lab1/lab1.html")

        user_message = driver.find_element_by_name("user_message")
        posted_message_0 = driver.find_element_by_id("posted-message-0")
        posted_message_1 = driver.find_element_by_id("posted-message-1")
        posted_message_2 = driver.find_element_by_id("posted-message-2")
        posted_message_3 = driver.find_element_by_id("posted-message-3")
        posted_message_4 = driver.find_element_by_id("posted-message-4")

        def test_messages_visibility(m1, m2, m3, m4, m5):
            assert (posted_message_0.is_displayed() == m1), "posted-message-0 should have been " + ("visible" if m1 else "hidden")
            assert (posted_message_1.is_displayed() == m2), "posted-message-1 should have been " + ("visible" if m2 else "hidden")
            assert (posted_message_2.is_displayed() == m3), "posted-message-2 should have been " + ("visible" if m3 else "hidden")
            assert (posted_message_3.is_displayed() == m4), "posted-message-3 should have been " + ("visible" if m4 else "hidden")
            assert (posted_message_4.is_displayed() == m5), "posted-message-4 should have been " + ("visible" if m5 else "hidden")

        def post_single_message(message):
            user_message.send_keys(message)
            user_message.send_keys(Keys.RETURN)
            user_message.clear()

        test_messages_visibility(False, False, False, False, False)

        post_single_message("First message")
        test_messages_visibility(True, False, False, False, False)

        #TODO: Alla meddelanden som visas skall ha en knapp som när man klickar markerar meddelandet som läst.

        mark_as_read_button_0 = driver.find_element_by_id("mark-as-read-button-0")
        assert ("alert-primary" in posted_message_0.get_attribute("class")), "Message was falsely marked as read"
        mark_as_read_button_0.click()
        assert ("alert-light" in posted_message_0.get_attribute("class")), "Message was not marked as read"

        post_single_message("Second message")
        test_messages_visibility(True, True, False, False, False)

        assert ("alert-primary" in posted_message_0.get_attribute("class")), "The top message should no longer be marked as read"
        mark_as_read_button_1 = driver.find_element_by_id("mark-as-read-button-1")
        assert ("alert-light" in posted_message_1.get_attribute("class")), "The second message should be marked as read"

        post_single_message("Third message")
        test_messages_visibility(True, True, True, False, False)

        post_single_message("Fourth message")
        test_messages_visibility(True, True, True, True, False)

        post_single_message("Fifth message")
        test_messages_visibility(True, True, True, True, True)

        posted_message_text_0 = driver.find_element_by_id("posted-message-text-0")
        posted_message_text_4 = driver.find_element_by_id("posted-message-text-4")

        assert (posted_message_text_0.get_attribute("innerHTML") == "Fifth message"), "The last message posted should be at the top"
        assert (posted_message_text_4.get_attribute("innerHTML") == "First message"), "The first message posted should be at the bottom"

    def tearDown(self):
        self.driver.close()


if __name__ == "__main__":
    unittest.main()


#unittest.test_max_characters(self)

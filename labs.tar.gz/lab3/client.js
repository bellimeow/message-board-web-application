function validateInput() {
    var message = document.getElementById("message").value;
    if (message.length > 140) {
        showPopup();
    } else if (message.length > 0) {
        requestPostMessage(message);
    }
}

var hidePopupTimerId
function showPopup() {
    var popup = document.getElementById("mypopup");
    popup.classList.add("show");
    window.clearTimeout(hidePopupTimerId);
    hidePopupTimerId = window.setTimeout(hidePopup, 3000);
}
function hidePopup() {
    var popup = document.getElementById("mypopup");
    popup.classList.remove("show");
}

function markElementAsRead(element, flag) {
    if (flag) {
        element.classList.remove("alert-primary");
        element.classList.add("alert-light");
    }
    else {
        element.classList.remove("alert-light");
        element.classList.add("alert-primary");
    }
}

/*******************************************************************************
    AJAX
*******************************************************************************/

function requestPostMessage(message) {
    $.get("http://localhost:3001/save", `message=${message}`, function(data, status) {
        if (status == "success") {
            requestUpdateMessageBoard();
        }
    });
}

// Array to store the ids of the posted messages.
// This array is updated by the 'requestUpdateMessageBoard' function.
var postedMessageIds = new Array();

function requestMarkAsRead(id, element) {
    var messageID = postedMessageIds[id];
    $.get("http://localhost:3001/flag", `ID=${messageID}`, function(data, status) {
        if (status == "success") {
            // Local update. Requesting messages from the server would be overkill here.
            markElementAsRead(element, true);
        }
    });
}

function requestUpdateMessageBoard() {
    $.get("http://localhost:3001/getall", "", function(data, status) {
        if (status == "success") {
            var i;
            for (i = 0; i < Math.min(5, data.length); i++) {
                var post = data[(data.length - 1) - i];
                postedMessageIds[i] = post._id;
                console.log(postedMessageIds[i]);

                var postedMessageElement = document.getElementById("posted-message-" + i);

                postedMessageElement.classList.add("show");

                markElementAsRead(postedMessageElement, post.flag);

                document.getElementById("posted-message-text-" + i).innerHTML = post.message;
            }
        }
    });
}

/*******************************************************************************
    INITIALIZATION
*******************************************************************************/

$(document).ready(function() {
    requestUpdateMessageBoard();

    $("#userform").on("submit", function(event) {
        validateInput();
    });
});

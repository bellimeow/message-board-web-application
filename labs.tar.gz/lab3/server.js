const express = require("express");
const ExpressApp = express();
const ExpressPort = 3001;
const MongoClient = require('mongodb').MongoClient;
const MongoURL = "mongodb://localhost:27017/";
const ObjectID = require('mongodb').ObjectID;

/*******************************************************************************
        ROUTES
*******************************************************************************/

ExpressApp.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
ExpressApp.use(express.static(__dirname));
ExpressApp.use(express.static(__dirname + "/.."));
ExpressApp.use(express.json());
ExpressApp.use(express.urlencoded());

// curl -d "msg=hej" -X POST http://localhost/msg_new

// We created our own convenience function for setting up routes.
// See "function route" below.

/**
* This is the route used to add new messages to the message board. The messages
* are saved to a collection 'messages' in the Mongo database.
 **/
route(ExpressApp, "get", "/save", function(req, res) {
    var message = req.query.message;

    if (message && message.length > 0 && message.length <= 140) {
        accessCollection("messages", function(db, messages) {
            messages.insertOne({ "message": message, "flag": false, }, function(err) {
                if (err) throw err;

                // Send OK status!
                res.sendStatus(200);

                db.close();
            });
        });
    }
    else {
        // Send bad request.
        res.sendStatus(400);
    }
});

route(ExpressApp, "get", "/flag", function(req, res) {
    // Required parameters.
    var id = req.query.ID;

    if (id) {
        accessCollection("messages", function(db, messages) {
            // Convert id to proper object recognized by MongoDB.
            try {
                id = ObjectID(id);
                messages.findOne(id, function(err, findRes) {
                    if (err) throw err;

                    if (findRes) {
                        // Update attribute value of the entry.
                        findRes.flag = true;

                        // Update the database entry.
                        messages.update({ "_id": id }, findRes, {}, function(err, updateRes) {
                            if (err) throw err;

                            res.sendStatus(200);

                            db.close();
                        });
                    }
                    else {
                        res.sendStatus(500);
                    }
                });
            }
            catch(err) {
                res.sendStatus(500);
            }
        });
    }
    else {
        res.sendStatus(400);
    }
});

/**
* This is the route used to get all existing messages on the message board.
 **/
route(ExpressApp, "get", "/getall", function(req, res) {
    accessCollection("messages", function(db, messages) {
        messages.find().toArray(function(err, findRes) {
            res.send(findRes);

            db.close();
        });
    });
});
// For testing!
route(ExpressApp, "get", "/testall", function(req, res) {
    accessCollection("messages", function(db, messages) {
        messages.find().toArray(function(err, findRes) {
            res.send(findRes);

            db.close();
        });
    });
});

// This is just for testing!
route(ExpressApp, "get", "/drop", function(req, res) {
    if (req.query.confirm == "yes") {
        MongoClient.connect(MongoURL, function(err, db) {
            if (err) throw err;

            var dbo = db.db("tdp013");
            var messages = dbo.collection("messages");
            messages.drop(function(err, dropRes) {
                if (err) throw err;

                res.sendStatus(200);

                db.close();
            });
        });
    }
    else {
        res.sendStatus(400);
    }
});

var server;
if (!module.parent) {
    server = ExpressApp.listen(ExpressPort, function() {
        var host = server.address().address;
        var port = server.address().port;

        console.log('Example app listening at http://%s:%s', host, port);
    });
}

/*******************************************************************************
    DEFAULT ROUTE HANDLERS
*******************************************************************************/

// Function to set up a main method handler and use a default 405 handler for other methods.
function route(app, method, route, callback) {
    const allMethods = [
        "get",
        "post",
        "put",
        "head",
        "delete",
        "patch",
        "options",
    ];

    // Call the function by it's name.
    app[method](route, callback);

    // Loop through other methods and assign default handler.
    var i;
    for (var i = 0; i < allMethods.length; ++i) {
        if (allMethods[i] != method) {
            app[allMethods[i]](route, function(req, res) {
                res.sendStatus(405);
            });
        }
    }
}

/*******************************************************************************
    DATABASE
*******************************************************************************/

function accessCollection(collectionName, callback) {
    MongoClient.connect(MongoURL, function(err, db) {
        if (err) throw err;

        var dbo = db.db("tdp013");
        var collection = dbo.collection(collectionName);

        callback(db, collection);
    });
}
